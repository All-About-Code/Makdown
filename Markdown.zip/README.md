# This is a test project

A line

### start a line with a # to make a header (the type of header is depending on the type number of #'s)

>a quote
>
>it is here to!
>
> This is still here!

*Italic*

_also italic_

**Bold**

__Also Bold__

* A list
 * a nested list

- a different kind of list
 - and a nested list again

Some markdown: ``` _Italic_ or __Bold__ or *Italic* or **Bold** ```

    This is a blockquote!
    and continues

# Googles Logo:
![Google Logo](https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png)

A link: https://www.google.com

Another link: [Google](https://www.google.com)

More code:

```html
 <h1 id="click">Hello World in markup using markdown!</h1>
```
```css
 h1 {
   color: teal;
 }
```
```javascript
 getElementById('click').addEventListener("click", function(){

 });
```

| 1              | 2              |
| :------------- | :------------- |
| Item One       | Item Two       |

~~not a table!~~

Check one of me:

* [ ]

* [ ]
